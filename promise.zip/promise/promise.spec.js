
const Promise = require('./promise')

// sync plain promise
let a = Promise.resolve(true)

// promise value (will call then internally)
let b = Promise.resolve(a)
