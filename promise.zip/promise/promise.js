
'use strict'

// constants
const PENDING = 0
const REJECTED = 2
const FULFILLED = 1
const NOOP = () => {}

// export
module.exports = Promise

/**
 * 
 * 
 * @class
 */
class Promise {
  /**
   * Initialize a new Promise instance
   * 
   * @param {Function} fn
   * @constructor
   */
  constructor (fn) {
    /**
     * Promise value
     * 
     * @type {Any}
     * @private
     */
    this._value = null

    /**
     * Promise state
     * 
     * @type {Number}
     * @private
     */
    this._state = PENDING

    /**
     * Source promise
     * 
     * @type {Promise}
     * @private
     */
    this._parent = null

    /**
     * Promise follower
     * 
     * @type {Promise|Array<Promise>}
     * @private
     */
    this._receiver = null

    /**
     * Promise fulfillment listener
     * 
     * @type {Function}
     * @private
     */
    this._onRejected = null

    /**
     * Promise rejection listener
     * 
     * @type {Function}
     * @private
     */
    this._onFulfilled = null

    // execute
    if (fn !== NOOP) _tryExecutor(this, fn)
  }

  /**
   * 
   * 
   * @param {Any} value
   * @returns {Promise}
   * @static
   */
  static resolve (value) {
    return new Promise((resolve) => resolve(value))
  }

  /**
   * 
   * 
   * @param {Error} error
   * @returns {Promise}
   * @static
   */
  static reject (error) {
    return new Promise((_, reject) => reject(error))
  }

  /**
   * 
   * 
   * @param {Function} onFulfilled
   * @param {Function} [onRejected]
   * @returns {Promise}
   * @public
   */
  then (onFulfilled, onRejected = null) {
    // TODO assert onFulfilled or onRejected is provided
    // TODO assert provided callback is a function
    return _next(this, onFulfilled, onRejected)
  }

  /**
   * 
   * 
   * @param {Function} onRejected
   * @returns {Promise}
   * @public
   */
  catch (onRejected) {
    // TODO assert onRejected is a function
    return this.then(null, onRejected)
  }

  /**
   * 
   * 
   * @returns {String}
   */
  toString () {
    return '[object Promise]'
  }
}

/**
 * Try invoking the executor
 * 
 * @param {Promise} promise
 * @param {Function} fn
 * @private
 */
function _tryExecutor (promise, fn) {
  // make sure `doResolve` and `doReject` are only called once
  var called = false

  try {
    fn(function doResolve (result) {
      if (!called) {
        called = true
        _resolve(promise, result)
      }
    }, function doReject (error) {
      if (!called) {
        called = true
        _reject(promise, error)
      }
    })
  } catch (error) {
    if (!called) {
      called = true
      _reject(promise, error)
    }
  }
}

/**
 * 
 * 
 * @param {Promise} promise
 * @param {Any} value
 * @private
 */
function _resolve (promise, value) {
  // plain value
  if (!value || !value.then) {
    _settle(promise, FULFILLED, value)
    return
  }

  // promise like
  value.then(
    (result) => _settle(promise, FULFILLED, result),
    (error) => _reject(promise, error)
  )
}

/**
 * 
 * 
 * @param {Promise} promise
 * @param {Error} value
 * @private
 */
function _reject (promise, value) {
  _settle(promise, REJECTED, value)
}

/**
 * 
 * 
 * @param {Promise} promise
 * @param {Number} state
 * @param {Any} value
 * @private
 */
function _settle (promise, state, value) {
  promise._state = state
  promise._value = value

  if (promise._receiver) {
    _notify(promise, promise._receiver)
    promise._receiver = null
  }
}

/**
 * 
 * 
 * @param {Promise} promise
 * @param {Function} [onFulfilled]
 * @param {Function} [onRejected]
 * @returns {Promise}
 * @private
 */
function _next (promise, onFulfilled, onRejected) {
  var receiver = new Promise(NOOP)

  receiver._parent = promise
  receiver._onRejected = onRejected
  receiver._onFulfilled = onFulfilled

  _addReceiver(promise, receiver)

  return receiver
}

/**
 * 
 * 
 * @param {Promise} promise
 * @param {Promise} receiver
 * @private
 */
function _addReceiver (promise, receiver) {
  // pending
  if (source._state === PENDING) {
    if (!promise._receiver) {
      promise._receiver = receiver
    }
    else if (Array.isArray(promise._receiver)) {
      promise._receiver.push(receiver)
    }
    else {
      promise._receiver = [promise._receiver, receiver]
    }

    return
  }

  // settled
  _notify(promise, receiver)
}

/**
 * 
 * 
 * @param {Promise} promise
 * @param {Promise} receiver
 * @private
 */
function _notify (promise, receiver) {
  // mutilple receivers
  if (Array.isArray(receiver)) {
    for (let i = 0; i < receiver.length; i++) {
      _notify(promise, receiver[i])
    }

    return
  }

  if (promise._state === FULFILLED) {
    setImmediate(_tryCallback, promise, receiver._onFulfilled)
  }
  else {
    setImmediate(_tryCallback, promise, receiver._onRejected)
  }
}

/**
 * 
 * 
 * @param {Promise} promise
 * @param {Function} fn
 * @private
 */
function _tryCallback (promise, fn) {
  try {
    var result = fn(promise._value)

    _resolve(promise, result)
  } catch (error) {
    _reject(promise, error)
  }
}
